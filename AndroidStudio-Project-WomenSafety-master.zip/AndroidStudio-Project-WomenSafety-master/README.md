# WomenSafety

<img src = "https://github.com/iamjithinjohnson/AndroidStudio-Project-Women-Safety/blob/master/defence3.jpg" width=300 height=300> <img src = "https://github.com/iamjithinjohnson/AndroidStudio-Project-WomenSafety/blob/master/preview.png" width=170 height=300>



An android app which can INSTANTLY alert the Guardians( along with user location ) whenever the user is in an emergency situation.

Project Video https://www.youtube.com/watch?v=vPCtDNXqf1E

### Software Requirement
- Android Studio
- Wamp Server
- Internet Connection
- Java
- [PHP]
- MYSQL

### DataBase
<img src = "https://github.com/iamjithinjohnson/AndroidStudio-Project-WomenSafety/blob/master/database/Screenshot_21.png" >
<img src = "https://github.com/iamjithinjohnson/AndroidStudio-Project-WomenSafety/blob/master/database/Screenshot_22.png" >
<img src = "https://github.com/iamjithinjohnson/AndroidStudio-Project-WomenSafety/blob/master/database/Screenshot_23.png" >




License
----


**Free Software, Hell Yeah!**

[PHP]: <https://github.com/iamjithinjohnson/AndroidStudio-Project-WomenSafety/tree/master/php>
