package com.example.jithin.womensafety;

/**
 * Created by jithin on 4/24/2020.
 */

public class Constant {

    private static final String ROOT_URL = "http://192.168.43.150/emergency/v1/";
    public static final String URL_CONTACT = ROOT_URL+"contact.php";
    public static final String URL_MESSAGE = ROOT_URL+"contact2.php";
    public static final String URL_CALL = ROOT_URL+"contact1.php";
    public static final String URL_REMOVE = ROOT_URL+"remove.php";
    public static final String URL_INSERT = ROOT_URL+"insert.php";
    public static final String URL_LOGIN = ROOT_URL+"login.php";
    public static final String URL_REGISTER = ROOT_URL+"register.php";



    public static final String URL_INSERTGRAPES = "https://www.grapestechs.com/GPTC/st_joseph/Emergency_call/add_friend.php";
    public static final String URL_CONTACTGRAPES = "http://grapestechs.com/GPTC/st_joseph/Emergency_call/list.php";
    public static final String URL_MESSAGEGRAPES = "https://www.grapestechs.com/GPTC/st_joseph/Emergency_call/message.php";
    public static final String URL_CALLGRAPES = "https://www.grapestechs.com/GPTC/st_joseph/Emergency_call/call.php";
    public static final String URL_REMOVEGRAPES = "http://grapestechs.com/GPTC/st_joseph/Emergency_call/delete_friend.php";
    public static final String URL_LOGINGRAPES = "https://www.grapestechs.com/GPTC/st_joseph/Emergency_call/login.php";
    public static final String URL_REGISTERGRAPES = "https://www.grapestechs.com/GPTC/st_joseph/Emergency_call/reg.php";






}
